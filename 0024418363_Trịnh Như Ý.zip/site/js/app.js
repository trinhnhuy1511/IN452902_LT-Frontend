// Câu 2: viết JavaScript tại đây

const API_URL = 'http://localhost:4000/api';

const formatDateTime = (iso) =>
  new Date(iso).toLocaleString('vi-VN', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: '2-digit', year: 'numeric',
  });

const formatSeats = (event) => {
    const remaining = event.capacity - event.registeredCount;
    if (remaining <= 0) {
        return "Hết chỗ";
    }
    return `Còn ${remaining}/${event.capacity} chỗ`;
};
const renderEvents = (events) => {
    const eventList = document.getElementById('event-list');
    const cards = events.map((event, index) => {
        const article = document.createElement('article');
        article.className = 'event-card';

        const img = document.createElement('img');
        img.setAttribute('src', event.image || (index % 2 === 0 ? 'img/workshop.jpg' : 'img/hackathon.jpg'));
        img.setAttribute('alt', event.name);
        article.appendChild(img);

        const h3 = document.createElement('h3');
        const a = document.createElement('a');
        a.setAttribute('href', `event-detail.html?id=${event.id}`);
        a.textContent = event.name;
        h3.appendChild(a);
        article.appendChild(h3);

        const pTime = document.createElement('p');
        pTime.textContent = 'Thời gian: ';
        const timeTag = document.createElement('time');
        timeTag.setAttribute('datetime', event.startTime);
        timeTag.textContent = typeof formatDateTime === 'function' ? formatDateTime(event.startTime) : event.startTime;
        pTime.appendChild(timeTag);
        article.appendChild(pTime);

        const pLocation = document.createElement('p');
        pLocation.textContent = `Địa điểm: ${event.location}`;
        article.appendChild(pLocation);

        const pSeats = document.createElement('p');
        pSeats.className = 'seats';
        const seatsText = formatSeats(event);
        pSeats.textContent = seatsText;
        article.appendChild(pSeats);

        if (seatsText === "Hết chỗ") {
            const badge = document.createElement('span');
            badge.className = 'badge';
            badge.textContent = "Hết chỗ";
            article.appendChild(badge);
        }

        return article;
    });

    eventList.replaceChildren(...cards);
};

document.addEventListener('DOMContentLoaded', () => {
    loadEvents();

    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const keywordInput = document.getElementById('keyword');
            const keyword = keywordInput ? keywordInput.value : '';
            loadEvents(keyword);
        });
    }
});
